create env

create requirements.txt file

install req.txt

download data from

https://drive.google.com/drive/folders/18zqQiCJVgF7uzXgfbIJ-04zgz1ItNfF5

git init

dvc init
dvc add data_given\winequality.csv

git add . && git commit -m "first commit"
